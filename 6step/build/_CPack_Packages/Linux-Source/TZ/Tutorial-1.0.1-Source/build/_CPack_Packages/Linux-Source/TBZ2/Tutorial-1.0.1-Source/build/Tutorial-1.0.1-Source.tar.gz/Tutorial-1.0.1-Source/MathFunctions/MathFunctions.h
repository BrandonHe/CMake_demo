#ifndef _MATHFUNCTIONS_H_
#define _MATHFUNCTIONS_H_
double mysqrt(double x);
#endif //_MATHFUNCTIONS_H_
